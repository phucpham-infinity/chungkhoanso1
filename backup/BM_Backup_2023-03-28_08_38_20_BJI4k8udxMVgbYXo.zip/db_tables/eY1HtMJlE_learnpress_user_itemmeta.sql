/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_user_itemmeta`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_learnpress_user_itemmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_learnpress_user_itemmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `learnpress_user_item_id` bigint(20) unsigned NOT NULL, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `meta_value` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `extra_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `learnpress_user_item_id` (`learnpress_user_item_id`), KEY `meta_key` (`meta_key`(191)), KEY `meta_value` (`meta_value`(191))) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
