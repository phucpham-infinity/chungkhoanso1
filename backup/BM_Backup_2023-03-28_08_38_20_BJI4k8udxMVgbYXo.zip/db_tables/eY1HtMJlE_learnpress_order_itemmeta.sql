/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_order_itemmeta`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_learnpress_order_itemmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_learnpress_order_itemmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `learnpress_order_item_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `meta_value` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `extra_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `learnpress_order_item_id` (`learnpress_order_item_id`), KEY `meta_key` (`meta_key`(191)), KEY `meta_value` (`meta_value`(191))) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679992701_eY1HtMJlE_learnpress_order_itemmeta` (`meta_id`, `learnpress_order_item_id`, `meta_key`, `meta_value`, `extra_value`) VALUES (1,1,'_course_id',150,''),(2,1,'_quantity',1,''),(3,1,'_subtotal',0,''),(4,1,'_total',0,''),(5,2,'_course_id',150,''),(6,2,'_quantity',1,''),(7,2,'_subtotal',300000,''),(8,2,'_total',300000,'');
