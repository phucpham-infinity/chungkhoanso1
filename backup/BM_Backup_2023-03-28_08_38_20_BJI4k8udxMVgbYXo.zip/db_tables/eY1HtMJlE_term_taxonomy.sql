/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_term_taxonomy`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_term_taxonomy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_term_taxonomy` ( `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `term_id` bigint(20) unsigned NOT NULL DEFAULT 0, `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `parent` bigint(20) unsigned NOT NULL DEFAULT 0, `count` bigint(20) NOT NULL DEFAULT 0, PRIMARY KEY (`term_taxonomy_id`), UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), KEY `taxonomy` (`taxonomy`)) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679992701_eY1HtMJlE_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES (1,1,'category','',0,1),(2,2,'wpcode_type','',0,1),(3,3,'wpcode_location','',0,1),(4,4,'wpcode_tags','',0,2),(5,5,'wpcode_tags','',0,1),(6,6,'wpcode_type','',0,1),(7,7,'wpcode_location','',0,1),(8,8,'wpcode_tags','',0,1),(9,9,'wpcode_tags','',0,1),(10,10,'elementor_library_type','',0,1),(11,11,'nav_menu','',0,3),(12,12,'elementor_library_type','',0,6),(13,13,'elementor_library_type','',0,1);
