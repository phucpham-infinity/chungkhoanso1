/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_frmt_form_entry_meta`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_frmt_form_entry_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_frmt_form_entry_meta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `entry_id` bigint(20) unsigned NOT NULL, `meta_key` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `date_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`meta_id`), KEY `meta_key` (`meta_key`), KEY `meta_entry_id` (`entry_id`), KEY `meta_key_object` (`entry_id`,`meta_key`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
