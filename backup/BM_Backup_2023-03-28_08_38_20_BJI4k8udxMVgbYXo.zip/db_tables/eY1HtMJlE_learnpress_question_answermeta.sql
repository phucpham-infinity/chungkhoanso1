/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_question_answermeta`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_learnpress_question_answermeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_learnpress_question_answermeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `learnpress_question_answer_id` bigint(20) unsigned NOT NULL, `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `question_answer_meta` (`learnpress_question_answer_id`,`meta_key`(150))) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
