/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_user_item_results`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_learnpress_user_item_results`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_learnpress_user_item_results` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `user_item_id` bigint(20) unsigned NOT NULL, `result` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, PRIMARY KEY (`id`), KEY `user_item_id` (`user_item_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
