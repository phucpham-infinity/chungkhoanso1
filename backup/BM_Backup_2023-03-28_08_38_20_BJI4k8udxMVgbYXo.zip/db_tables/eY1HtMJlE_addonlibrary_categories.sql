/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_addonlibrary_categories`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_addonlibrary_categories`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_addonlibrary_categories` ( `id` int(9) NOT NULL AUTO_INCREMENT, `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL, `alias` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `ordering` int(11) NOT NULL, `params` text COLLATE utf8mb4_unicode_520_ci NOT NULL, `type` tinytext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `parent_id` int(9) DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679992701_eY1HtMJlE_addonlibrary_categories` (`id`, `title`, `alias`, `ordering`, `params`, `type`, `parent_id`) VALUES (1,'Creative Widgets','creative_widgets',1,'','elementor','');
