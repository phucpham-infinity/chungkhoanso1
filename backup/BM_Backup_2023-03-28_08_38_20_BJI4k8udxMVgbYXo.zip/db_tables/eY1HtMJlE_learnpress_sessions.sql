/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_sessions`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_learnpress_sessions`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_learnpress_sessions` ( `session_id` bigint(20) NOT NULL AUTO_INCREMENT, `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL, `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `session_expiry` bigint(20) NOT NULL, PRIMARY KEY (`session_key`), UNIQUE KEY `session_id` (`session_id`)) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
