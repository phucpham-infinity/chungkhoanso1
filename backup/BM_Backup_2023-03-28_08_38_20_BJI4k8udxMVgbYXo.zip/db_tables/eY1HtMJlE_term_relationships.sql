/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_term_relationships`; */
/* PRE_TABLE_NAME: `1679992701_eY1HtMJlE_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679992701_eY1HtMJlE_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679992701_eY1HtMJlE_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0),(16,2,0),(16,3,0),(16,4,0),(16,5,0),(17,6,0),(17,7,0),(17,4,0),(17,8,0),(17,9,0),(350,10,0),(361,11,0),(360,11,0),(362,11,0),(579,12,0),(366,10,0),(378,10,0),(404,10,0),(582,13,0),(595,13,0),(711,12,0),(784,12,0),(820,12,0),(847,12,0),(1000,12,0);
