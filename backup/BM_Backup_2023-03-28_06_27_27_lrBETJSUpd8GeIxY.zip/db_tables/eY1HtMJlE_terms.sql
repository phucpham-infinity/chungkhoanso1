/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_terms`; */
/* PRE_TABLE_NAME: `1679984848_eY1HtMJlE_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679984848_eY1HtMJlE_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT 0, PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679984848_eY1HtMJlE_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Uncategorized','uncategorized',0),(2,'text','text',0),(3,'after_paragraph','after_paragraph',0),(4,'sample','sample',0),(5,'message','message',0),(6,'php','php',0),(7,'everywhere','everywhere',0),(8,'disable','disable',0),(9,'comments','comments',0),(10,'header','header',0),(11,'Main Menu','main-menu',0),(12,'section','section',0),(13,'footer','footer',0);
