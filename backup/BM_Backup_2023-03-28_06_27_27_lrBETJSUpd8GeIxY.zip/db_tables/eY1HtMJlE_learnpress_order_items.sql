/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_learnpress_order_items`; */
/* PRE_TABLE_NAME: `1679984848_eY1HtMJlE_learnpress_order_items`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679984848_eY1HtMJlE_learnpress_order_items` ( `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `order_item_name` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL, `order_id` bigint(20) unsigned NOT NULL DEFAULT 0, `item_id` bigint(20) unsigned NOT NULL DEFAULT 0, `item_type` varchar(45) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', PRIMARY KEY (`order_item_id`), KEY `order_id` (`order_id`), KEY `item_id` (`item_id`), KEY `item_type` (`item_type`)) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1679984848_eY1HtMJlE_learnpress_order_items` (`order_item_id`, `order_item_name`, `order_id`, `item_id`, `item_type`) VALUES (1,'Khoá học mẫu',298,150,'lp_course'),(2,'Khoá học mẫu',300,150,'lp_course');
