/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_frmt_form_views`; */
/* PRE_TABLE_NAME: `1679984848_eY1HtMJlE_frmt_form_views`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679984848_eY1HtMJlE_frmt_form_views` ( `view_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `form_id` bigint(20) unsigned NOT NULL, `page_id` bigint(20) unsigned NOT NULL, `ip` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `count` mediumint(8) unsigned NOT NULL DEFAULT 1, `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `date_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`view_id`), KEY `view_form_id` (`form_id`), KEY `view_ip` (`ip`), KEY `view_form_object` (`form_id`,`view_id`), KEY `view_form_object_ip` (`form_id`,`view_id`,`ip`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
