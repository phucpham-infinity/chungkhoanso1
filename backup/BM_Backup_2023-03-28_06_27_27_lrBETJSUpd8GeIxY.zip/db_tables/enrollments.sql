/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `enrollments`; */
/* PRE_TABLE_NAME: `1679984848_enrollments`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679984848_enrollments` ( `id` int(11) NOT NULL AUTO_INCREMENT, `student_id` int(11) NOT NULL, `course_id` int(11) NOT NULL, `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp(), `created_at` timestamp NOT NULL DEFAULT current_timestamp(), `updated_at` timestamp NOT NULL DEFAULT current_timestamp(), PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
INSERT INTO `1679984848_enrollments` (`id`, `student_id`, `course_id`, `status`, `enrolled_at`, `created_at`, `updated_at`) VALUES (2,1,8,'START','2023-03-28 01:01:54','2023-03-28 01:01:54','2023-03-28 01:01:54'),(10,1,4,'COMPLETE','2023-03-28 11:55:16','2023-03-28 11:55:16','2023-03-28 11:55:16');
