/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `eY1HtMJlE_frmt_form_entry`; */
/* PRE_TABLE_NAME: `1679984848_eY1HtMJlE_frmt_form_entry`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1679984848_eY1HtMJlE_frmt_form_entry` ( `entry_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `entry_type` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL, `draft_id` varchar(12) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL, `form_id` bigint(20) unsigned NOT NULL, `is_spam` tinyint(1) NOT NULL DEFAULT 0, `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', PRIMARY KEY (`entry_id`), KEY `entry_is_spam` (`is_spam`), KEY `entry_type` (`entry_type`), KEY `entry_form_id` (`form_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
